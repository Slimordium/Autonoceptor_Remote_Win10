﻿#pragma once

class Autono
{
	
	public:
		static void update_rpm();
		static void read_lidar_data();
		static void write_imu_status();
		static void set_steering();
		static void set_throttle();
		static void write_data_frame_to_serial();
		static void read_pixy_data();
		static void read_lidar_servo_position();
		static void get_imu_calibration();
		static void deserialize_command();

		enum command
		{
			set_steering_pwm,
			set_throttle_pwm,
			set_rpm_target,
			pixy_steering_enabled,
			get_current_telemetry_frame,
			telemetry_stream_enabled,
			get_imu_calibration_status,
			set_yaw_offset,
			set_steering_offset,
			set_throttle_automatic
		};
};
